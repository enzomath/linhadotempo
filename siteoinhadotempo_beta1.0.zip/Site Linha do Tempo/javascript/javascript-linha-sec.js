//Botar o texto
function secxxac(){
//sec XX a.C - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec20ac.innerHTML = '<div onclick="volta(20)" style="text-decoration: none; color: black"> <img src="img/icon-preto.png" alt="" class="icon-preto-1"> <p class="sec-r">Séc. XX a.C</p></a>                                 <div class="content-sec content-right">  <b>Principais acontecimentos:</b><br><hr><i>• 2000 a.C.: Acredita-se que Stonehenge foi completada.<br><hr>• Cerca de 2000 a.C.: Idade do Bronze começa no norte da China Antiga.<br><hr>• 2064 a.C.–1986 a.C.: Guerra das Dinastias Gêmeas no Egito.<br><hr>• 2000 a.C.: Chegada dos ancestrais dos latinos na Itália.</i><hr><br><a href="page-sec20a.C.html">Leia Mais>>></a></div>';
};

//sec XIX a.C - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec19a.C.html">
function secxixac(){
  sec19ac.innerHTML = '<div onclick="volta(19)" style="text-decoration: none; color: black; cursor: pointer">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. XIX a.C</p>     </div> <div class="content-sec content-left">   <b>Principais acontecimentos:</b><br><hr><i>• 1991 a.C.: Antigo Egito: Faraó Mentuotepe IV morreu. Fim da XI dinastia egípcia. Faraó Amenemés I começa a reger. Início da XII dinastia egípcia.<br><hr>•Cerca de 1985 a.C.: Autoridade política torna-se menos centralizada no Egito Antigo.<br></i><hr><br> <a href="page-sec19a.C.html">Leia Mais>>></a>                    </div>';};
function secxviiiac(){
//sec XVIII a.C - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec18ac.innerHTML= '<div onclick="volta(18)" style="text-decoration: none; color: black; cursor: pointer"> <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. XVIII a.C</p> </div>                                 <div class="content-sec content-right"><b>Principais acontecimentos:</b><br><hr><i>adicionar_conteudo</i><hr><br>         <a href="page-sec18a.C.html">Leia Mais>>></a></div>';
};
function secxviiac(){
  //Seculo 17 a.c
  sec17ac.innerHTML='   <div onclick="volta(17)" style="text-decoration: none; color: black; cursor pointer">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. XVII a.C</p>       </div>        <div class="content-sec content-left">  <b>Principais acontecimentos:</b><br><hr><i>• Surgimento da escrita alfabética, documento sintático, alfabeto semítico setentrional – (Entre 1700 – 1500 a. C.)<hr></i><a href="page-sec17a.C.html">Leia Mais>>></a>                    </div>';
};
function secxviac() {
  //sec XVI a.C - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec16ac.innerHTML = '<div onclick="volta(16)" style="text-decoration: none; color: black; cursor: pointer"> <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. XVI a.C</p></div>                                 <div class="content-sec content-right">  <b>Principais acontecimentos:</b><br><hr><i>• Início da Grécia Micênica - (1600 a. C.)<br><hr>• Início do Império novo Egito – (1580 a. C.)<br></i><hr><br>   <a href="page-sec16a.C.html">Leia Mais>>></a></div>';
};
function secxvac() {
  //Seculo 15 a.c
  sec15ac.innerHTML = '   <div onclick="volta(15)" style="text-decoration: none; color: black">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. XV a.C</p></div>            <div class="content-sec content-left">                       Sem Conteudo Pesquisado  <a href="page-sec15a.C.html">Leia Mais>>></a>                    </div>';
};
function secxivac() {
  //sec XIV a.C - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec14ac.innerHTML = '<div onclick="volta(14)" style="text-decoration: none; color: black; cursor: pointer"> <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. XIV a.C</p></div>                                 <div class="content-sec content-right">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Incidunt perferendis itaque aut et accusantium, eaque debitis.                  Doloremque cumque ea consequuntur nam ratione aliquam tenetur id. Harum similique rem voluptate adipisci.         <a href="page-sec14a.C.html">Leia Mais>>></a></div>';
};

function secxiiiac() {
  //Seculo 13 a.c
  sec13ac.innerHTML = '   <div onclick="volta(13)" style="text-decoration: none; color: black; cursor: pointer">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. XIII a.C</p>  </div>             <div class="content-sec content-left">                         Lorem, ipsum dolor sit amet consectetur adipisicing elit.                         Incidunt perferendis itaque aut et accusantium, eaque debitis.                        Doloremque cumque ea consequuntur nam ratione aliquam tenetur id.                       Harum similique rem voluptate adipisci. <a href="page-sec13a.C.html">Leia Mais>>></a>                    </div>';
};
function secxiiac() {
  //sec XII a.C - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec12ac.innerHTML = '<div onclick="volta(12)" style="text-decoration: none; color: black; cursor: pointer"> <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. XII a.C</p></div>                                 <div class="content-sec content-right">    <b>Principais acontecimentos:</b><br><hr><i>• Período Homérico Séculos XII a.C (estende-se até o século VII a.C)<br></i>     <a href="page-sec12a.C.html">Leia Mais>>></a></div>';
};
function secxiac() {
  //Seculo 11 a.c
  sec11ac.innerHTML = '  <div onclick="volta(11)" style="text-decoration: none; color: black; cursor: pointer">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. XI a.C</p>  </div>             <div class="content-sec content-left">                         Lorem, ipsum dolor sit amet consectetur adipisicing elit.                         Incidunt perferendis itaque aut et accusantium, eaque debitis.                        Doloremque cumque ea consequuntur nam ratione aliquam tenetur id.                       Harum similique rem voluptate adipisci. <a href="page-sec11a.C.html">Leia Mais>>></a>                    </div>';
};
function secxac() {
  //sec X a.C - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec10ac.innerHTML = '<div onclick="volta(10)" style="text-decoration: none; color: black; cursor: pointer"> <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. X a.C</p></div>                                 <div class="content-sec content-right">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Incidunt perferendis itaque aut et accusantium, eaque debitis.                  Doloremque cumque ea consequuntur nam ratione aliquam tenetur id. Harum similique rem voluptate adipisci.         <a href="page-sec10a.C.html">Leia Mais>>></a></div>';
};
function secixac() {
  //Seculo 9 a.c
  sec9ac.innerHTML = '   <div onclick="volta(9)" style="text-decoration: none; color: black; cursor: pointer">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. IX a.C</p>    </div>           <div class="content-sec content-left">                          <b>Principais acontecimentos:</b><br><hr><i>• Fim do Reinado de Polidectes, rei de Esparta desde 830 a.C<br></i>     <a href="page-sec9a.C.html">Leia Mais>>></a>                    </div>';
};
function secviiiac() {
  //sec viii a.C - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec8ac.innerHTML = '<div onclick="volta(8)" style="text-decoration: none; color: black; cursor: pointer"> <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. VIII a.C</p></div>                                 <div class="content-sec content-right"> <b>Principais acontecimentos:</b><br><hr><i>• Cividade de Terroso<br><hr>• Hititas<br></i><hr><br><a href="page-sec8a.C.html">Leia Mais>>></a></div>';
}; 
function secviiac() {
  //Seculo 7 a.c
  sec7ac.innerHTML = '<div onclick="volta(7)" style="text-decoration: none; color: black; cursor: pointer">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. VII a.C</p>       </div>        <div class="content-sec content-left">   <b>Principais acontecimentos:</b><i>• Hesíodo(700 a.C)</i> <a href="page-sec7a.C.html">Leia Mais>>></a>                    </div>';
};
function secviac() {
  //sec vi a.C - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec6ac.innerHTML = '<div onclick="volta(6)" style="text-decoration: none; color: black; cursor:pointer"> <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. VI  a.C</p> </div>                                 <div class="content-sec content-right">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Incidunt perferendis itaque aut et accusantium, eaque debitis.                  Doloremque cumque ea consequuntur nam ratione aliquam tenetur id. Harum similique rem voluptate adipisci.         <a href="page-sec6a.C.html">Leia Mais>>></a></div>';
};
function secvac() {
  //Seculo 5 a.c
  sec5ac.innerHTML = '   <div onclick="volta(5)" style="text-decoration: none; color: black; cursor: pointer">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. V a.C</p>       </div>        <div class="content-sec content-left">                        <b>Principais acontecimentos:</b><br><hr><i>• Período clássico da civilização Grega.<br><hr>• Guerras Médicas<br><hr>• A batalha do Peloponeso</i><hr><br><a href="page-sec5a.C.html">Leia Mais>>></a>                    </div>';
};
function secivac() {
  //sec iv a.C - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec4ac.innerHTML = '<div onclick="volta(4)" style="text-decoration: none; color: black; cursor:pointer"> <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. IV a.C</p></div>                                 <div class="content-sec content-right">  <b>Principais acontecimentos:</b><br><hr><i>• Período clássico da civilização Grega.<br><hr>• A batalha de Egospótamos<br><hr>• Início período Helenistico</i><hr><br><a href="page-sec4a.C.html">Leia Mais>>></a></div>';
};
function seciiiac() {
  //Seculo 3 a.c
  sec3ac.innerHTML = '   <div onclick="volta(3)" style="text-decoration: none; color: black; cursor: pointer">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. III a.C</p>       </div>        <div class="content-sec content-left">    <b>Principais acontecimentos:</b><br><hr><i>• Primeira guerra Punica(264-241 a.C.)<br><hr>• Segunda Guerra Punica(218-201 a.C.)</i><hr><br> <a href="page-sec3a.C.html">Leia Mais>>></a>                    </div>';
};
function seciiac() {
  //sec ii a.C - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec2ac.innerHTML = '<div onclick="volta(2)" style="text-decoration: none; color: black; cursor:pointer"> <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. II a.C</p></div>                                 <div class="content-sec content-right"> <b>Principais acontecimentos:</b><br><hr><i>• Controle do Mar Mediterrâneo pelo Império Romano<br><hr>• Primeira guerra servil Romana<hr>Segunda guerra servil Romana</i><hr><br>       <a href="page-sec2a.C.html">Leia Mais>>></a></div>';
};
function seciac() {
  //Seculo 1 a.c
  sec1ac.innerHTML = '   <div onclick="volta(1)" style="text-decoration: none; color: black; cursor: pointer">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. I a.C</p>       </div>        <div class="content-sec content-left">                         <b>Principais acontecimentos: </b><hr><i>   • Nascimento de Jesus Cristo (6 a.C estimado)<hr>• República Romana dá lugar ao Império Romano 27 a.C<hr>• Primeiro Triunvirato<hr>• Segundo Triunvirato<hr>• O Principado<hr>• Terceira Guerra Servil Romana <br> <hr> <a href="page-sec1a.C.html">Leia Mais>>></a>                    </div>';
};
function seci() {
  //sec i - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec1.innerHTML = '<div onclick="volta(101)" style="text-decoration: none; color: black; cursor:pointer"> <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. I</p></div>                                 <div class="content-sec content-right"><b>Principais acontecimentos:</b><i><hr>• Início do século 1<hr>• Guerra judaico-romana<hr>• O grande incêndio em Roma<br> <hr><a href="page-sec1.html">Leia Mais>>></a></div>';
};
function secii() {
  //Seculo 2 
  sec2.innerHTML = '   <div onclick="volta(22)" style="text-decoration: none; color: black; cursor: pointer">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. II</p>       </div>        <div class="content-sec content-left">  <b>Principais acontecimentos:</b><hr>• Apogeu Romano no século 2<br><hr> <a href="page-sec2.html">Leia Mais>>></a>                    </div>';
  
};
function seciii() {
  //sec iii - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec3.innerHTML = '<div onclick="volta(33)" style="text-decoration: none; color: black; cursor:pointer"> <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. III</p></div>                                 <div class="content-sec content-right"><b>Principais acontecimentos:</b><hr>• Crise do Império Romano<br><hr>   <a href="page-sec3.html">Leia Mais>>></a></div>';
};
function seciv() {
  //Seculo 4
  sec4.innerHTML = '   <div onclick="volta(44)" style="text-decoration: none; color: black; cursor: pointer">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. IV</p>       </div>        <div class="content-sec content-left">                         Lorem, ipsum dolor sit amet consectetur adipisicing elit.                         Incidunt perferendis itaque aut et accusantium, eaque debitis.                        Doloremque cumque ea consequuntur nam ratione aliquam tenetur id.                       Harum similique rem voluptate adipisci. <a href="page-sec4.html">Leia Mais>>></a>                    </div>';
};
function secv() {
  //sec 5 - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec5.innerHTML = '<div onclick="volta(55)" style="text-decoration: none; color: black; cursor:pointer"> <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. V</p></div>                                 <div class="content-sec content-right"><b>Principais acontecimentos:</b><i><hr>• Queda do Império Romano<hr>• Fim da antiguidade classica e início da idade Média<br> <hr>  <a href="page-sec5.html">Leia Mais>>></a></div>';
};
function secvi() {
  //Seculo 6
  sec6.innerHTML = '   <div onclick="volta(66)" style="text-decoration: none; color: black; cursor: pointer">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. VI</p>       </div>        <div class="content-sec content-left">  <b>Principais acontecimentos:</b><i><hr>• Maomé<br> <hr>   <a href="page-sec6.html">Leia Mais>>></a>                    </div>';
};
function secvii() {
  //sec 7 - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec7.innerHTML = '<div onclick="volta(77)" style="text-decoration: none; color: black; cursor:pointer"> <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. VII</p></div>                                 <div class="content-sec content-right"><b>Principais acontecimentos:</b><i><hr> Expansão Islâmica<hr> O Alcorão<hr> O objetivo de Maomé<br><hr><a href="page-sec7.html">Leia Mais>>></a></div>';
};
function secviii() {
  //Seculo 8
  sec8.innerHTML = '   <div onclick="volta(88)" style="text-decoration: none; color: black; cursor: pointer">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. VIII</p>       </div>        <div class="content-sec content-left">    <b>Principais acontecimentos:</b><i><hr>• BATALHA DE POITIERS (Séc. VIII)<br><hr> <a href="page-sec8.html">Leia Mais>>></a>                    </div>';
};
function secix() {
  //sec 9 - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec9.innerHTML = '<div onclick="volta(99)" style="text-decoration: none; color: black; cursor:pointer"> <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. IX</p></div>                                 <div class="content-sec content-right"><b>Principais acontecimentos:</b><i><hr>• Era dos Normandos<br><hr>    <a href="page-sec9.html">Leia Mais>>></a></div>';
};
function secx() {
  //Seculo 10
  sec10.innerHTML = '   <div onclick="volta(100)" style="text-decoration: none; color: black; cursor: pointer">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. X</p>       </div>        <div class="content-sec content-left"> <b>Principais acontecimentos:</b><i><hr>• 902: Descoberta da Groelândia, na chegada dos escandinavos pelo oeste;<hr>• 927: O reino da Inglaterra é criado (através de vários reinos anglo-saxões); <hr>• 930: Fundação do parlamento da Islândia, sendo o primeiro parlamento de toda a história da humanidade; <hr>• 936: A península da Coreia é unificada, pelo governo comunista de Kim Ilsung;<hr>• 938: Redação do primeiro documento em que o nome “Portugal” é mencionado; <hr>• 955: Os muçulmanos conquistam a cidade de Coimbra, em Portugal; <hr>• 982: Os vikings conquistam parte da Groelândia;<hr>• 992: A cidade italiana de Veneza estabelece o seu primeiro contato comercial de forma amistosa com o Império Bizantino;<br><hr></i> <a href="page-sec10.html">Leia Mais>>></a>                    </div>';
};
function secxi() {
  //sec 11 - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec11.innerHTML = '<div onclick="volta(111)" style="text-decoration: none; color: black; cursor:pointer"> <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. XI</p></div>                                 <div class="content-sec content-right"><b>Principais acontecimentos:</b><hr><i>• O rei Etelredo II realiza um massacre no dia de São Bricio<hr>• Cisma do Oriente<hr>• 1066: Normandos conquistam a Inglaterra<hr>• 1098: Primeira Cruzada</i><br><hr>  <a href="page-sec11.html">Leia Mais>>></a></div>';
};
function secxii() {
  //Seculo 12
  sec12.innerHTML = '   <div onclick="volta(122)" style="text-decoration: none; color: black; cursor: pointer">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. XII</p>       </div>        <div class="content-sec content-left">       <b>Principais acontecimentos:</b><i><hr>• 1118: Fundação da Ordem dos Templários<hr>• 1123: Primeiro Concílio de Latrão<hr>• 1139: Segundo Concílio de Latrão<hr>• 1147: Segunda Cruzada<hr>• 1189: Terceira Cruzada</i><br><hr> <a href="page-sec12.html">Leia Mais>>></a>                    </div>';
};
function secxiii() {
  //sec 13 - Para inserir texto - Substitua do inicio do Lorem Ipsum até o começo do <a href="page-sec20a.C.html">
  sec13.innerHTML = '<div onclick="volta(133)" style="text-decoration: none; color: black; cursor:pointer"> <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. XIII</p></div>                                 <div class="content-sec content-right"> <b>Principais acontecimentos:</b><hr><i>• Quarta Cruzada (Cruzada Comercial) (Séc. XIII)<br><hr><a href="page-sec13.html">Leia Mais>>></a></div>';
};
function secxiv() {
  //Seculo 14
  sec14.innerHTML = '   <div onclick="volta(144)" style="text-decoration: none; color: black; cursor: pointer">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. XIV</p>       </div>        <div class="content-sec content-left"> <b>Principais acontecimentos:</b><hr><i>• Guerra dos 100 anos (Séc. XIV a XV)<br><hr><a href="page-sec14.html">Leia Mais>>></a>                    </div>';
};


//Não mexer daqui pra baixo
//Função de Tirar o Texto
//Não mexa aqui!!! att: Enzo
//Se leu é broxa!!!!!
function volta(year){
if(year==20){
sec20ac.innerHTML = '  <div id="change20ac"> <div onclick="secxxac()" class="seculosdiv">                   <img src="img/icon-preto.png" alt="" class="icon-preto-1"> <p class="sec-r">Séc. XX a.C</p>                    </div> </div>';
}
else if(year==19){
sec19ac.innerHTML = '<div id="change19ac">   <div onclick="secxixac()" class="seculosdiv">                    <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. XIX a.C</p> </div></div>';
}
else if(year==18){
sec18ac.innerHTML='                   <div id="change18ac">                 <div onclick="secxviiiac()" class="seculosdiv">                   <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. XVIII a.C</p>                   </div>            </div>';
}
else if(year==17){
sec17ac.innerHTML = '<div id="change17ac">  <div onclick="secxviiac()" class="seculosdiv">                   <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. XVII a.C</p> </div></div>';
}
else if(year==16){
sec16ac.innerHTML = '  <div id="change16ac">                <div onclick="secxviac()" class="seculosdiv">                  <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. XVI a.C</p>                 </div>               </div>';
}
else if(year==15){
sec15ac.innerHTML='  <div id="change15ac">   <div onclick="secxvac()" class="seculosdiv">               <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. XV a.C</p> </a>    </div></div>';  
}else if(year==14){
sec14ac.innerHTML='     <div id="change14ac">                 <div  class="seculosdiv" onclick="secxivac()" style="text-decoration: none; color: black">                  <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. XIV a.C</p>                   </div>            </div>';  
}
else if(year==13) {
  sec13ac.innerHTML = '<div id="change13ac">    <div class="seculosdiv" onclick="secxiiiac()" style="text-decoration: none; color: black">                   <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. XIII a.C</p> </div></div>';
}
else if(year==12) {
  sec12ac.innerHTML = '               <div onclick="secxiiac()" class="seculosdiv">       <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. XII a.C</p>     </div>              ';
}
else if(year==11){
sec11ac.innerHTML = '   <div id="change11ac">  <div class="seculosdiv" onclick="secxiac()" style="text-decoration: none; color: black">                    <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. XI a.C</p> </div></div>';
}
else if(year==10){
sec10ac.innerHTML = '  <div id="change10ac">  <div class="seculosdiv" onclick="secxac()" style="text-decoration: none; color: black">                  <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. X a.C</p>                </div> </div>';
}
else if (year == 9) {
  sec9ac.innerHTML = '                <div id="change9ac">   <div class="seculosdiv" onclick="secixac()" style="text-decoration: none; color: black">                   <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. IX a.C</p> </div></div>';
}
else if(year == 8){
sec8ac.innerHTML ='                        <div id="change8ac">                 <div class="seculosdiv" onclick="secviiiac()" style="text-decoration: none; color: black">                   <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. VIII a.C</p>                 </div>                  </div>';
}
else if (year == 7) {
  sec7ac.innerHTML = '  <div id="change7ac">  <div class="seculosdiv" onclick="secviiac()" style="text-decoration: none; color: black">            <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. VII a.C</p> </div></div>';
}
else if (year == 6) {
  sec6ac.innerHTML = ' <div id="change6ac">               <div class="seculosdiv" onclick="secviac()" style="text-decoration: none; color: black">                  <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. VI a.C</p>                  </div>               </div>';
}
else if (year == 5) {
  sec5ac.innerHTML = '     <div id="change5ac">   <div class="seculosdiv" onclick="secvac()" style="text-decoration: none; color: black">                <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. V a.C</p> </div></div>';
}
else if (year == 4) {
  sec4ac.innerHTML = ' <div id="change4ac">                <div class="seculosdiv" onclick="secivac()" style="text-decoration: none; color: black">                  <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. IV a.C</p>               </div>                </div>';
}
else if (year == 3) {
  sec3ac.innerHTML = '<div id="change3ac">  <div class="seculosdiv" onclick="seciiiac()" style="text-decoration: none; color: black">                    <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. III a.C</p> </div></div>';
}
else if (year == 2) {
  sec2ac.innerHTML = '  <div id="change2ac">                <div class="seculosdiv" onclick="seciiac()" style="text-decoration: none; color: black"><img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. II a.C</p>   </div>        </div>'; 
}
else if (year == 1) {
  sec1ac.innerHTML = ' <div id="change1ac">      <div class="seculosdiv" onclick="seciac()" style="text-decoration: none; color: black">                    <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. I a.C</p> </div>  </div>';
}
else if (year == 101) {
  sec1.innerHTML = ' <div id="change1">                 <div onclick="seci()" class="seculosdiv">                   <img src="img/icon-preto.png" alt="" class="icon-preto"> <p class="sec-r">Séc. I</p>                 </div>                  </div>';
}
else if (year == 22) {
  sec2.innerHTML = '                                        <div id="change2">    <div class="seculosdiv" onclick="secii()"  >                   <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. II</p> </div></div>';
}
else if (year == 33) {
  sec3.innerHTML = '  <div id="change3">    <div class="seculosdiv" onclick="seciii()">                   <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-r">Séc. III</p> </div></div>';
}
else if (year == 44) {
  sec4.innerHTML = ' <div id="change4">    <div class="seculosdiv" onclick="seciv()" style="text-decoration: none; color: black">               <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. IV</p> </div></div>';
}
else if (year == 55) {
  sec5.innerHTML = '    <div id="change5">    <div class="seculosdiv" onclick="secv()" style="text-decoration: none; color: black">                   <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-r">Séc. V</p> </div></div>';
}
else if (year == 66) {
  sec6.innerHTML = '  <div id="change6">    <div class="seculosdiv" onclick="secvi()" style="text-decoration: none; color: black">          <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. VI</p> </div></div>';
}
else if (year == 77) {
  sec7.innerHTML = '<div id="change7">    <a href="#" onclick="secvii()" style="text-decoration: none; color: black">                    <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-r">Séc. VII</p> </a></div>';
}
else if (year == 88) {
  sec8.innerHTML = '  <div id="change8">   <div class="seculosdiv" onclick="secviii()" style="text-decoration: none; color: black">                    <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. VIII</p> </div></div>';
}
else if (year == 99) {
  sec9.innerHTML = '  <div id="change9">    <div onclick="secix()" style="text-decoration: none; color: black">                  <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-r">Séc. IX</p> </div></div>';
}
else if (year == 100) {
  sec10.innerHTML = '     <div id="change10">    <div onclick="secx()" style="text-decoration: none; color: black">                   <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. X</p> </div></div>';
}
else if (year == 111) {
  sec11.innerHTML = '   <div id="change11"> <div class="seculosdiv" onclick="secxi()" style="text-decoration: none; color: black">                  <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-r">Séc. XI</p> </div></div>';
}
else if (year == 122) {
  sec12.innerHTML = '<div id="change12">    <div class="seculosdiv" onclick="secxii()" style="text-decoration: none; color: black">                    <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. XII</p> </div></div>';
}
else if (year == 133) {
  sec13.innerHTML = '<div id="change13"> <div class="seculosdiv" onclick="secxiii()" style="text-decoration: none; color: black">                  <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-r">Séc. XIII</p> </div></div>';
}
else if (year == 144) {
  sec14.innerHTML = '                     <div id="change14">    <div class="seculosdiv" onclick="secxiv()" style="text-decoration: none; color: black">                    <img src="img/icon-preto.png" alt="" class="icon-preto"><p class="sec-l">Séc. XIV</p> </div></div>';
}
};
var sec19ac = document.getElementById("change19ac");
var sec20ac = document.getElementById("change20ac");
var sec17ac = document.getElementById("change17ac");
var sec16ac = document.getElementById("change16ac");
var sec15ac = document.getElementById("change15ac");
var sec14ac = document.getElementById("change14ac");
var sec18ac = document.getElementById("change18ac");
var sec13ac = document.getElementById("change13ac");
var sec12ac = document.getElementById("change12ac");
var sec11ac = document.getElementById("change11ac");
var sec10ac = document.getElementById("change10ac");
var sec9ac = document.getElementById("change9ac");
var sec8ac = document.getElementById("change8ac");
var sec7ac = document.getElementById("change7ac");
var sec6ac = document.getElementById("change6ac");
var sec5ac = document.getElementById("change5ac");
var sec4ac = document.getElementById("change4ac");
var sec3ac = document.getElementById("change3ac");
var sec2ac = document.getElementById("change2ac");
var sec1ac = document.getElementById("change1ac");
var sec1 = document.getElementById("change1");
var sec2 = document.getElementById("change2");
var sec3 = document.getElementById("change3");
var sec4 = document.getElementById("change4");
var sec5 = document.getElementById("change5");
var sec6 = document.getElementById("change6");
var sec7 = document.getElementById("change7");
var sec8 = document.getElementById("change8");
var sec9 = document.getElementById("change9");
var sec10 = document.getElementById("change10");
var sec11 = document.getElementById("change11");
var sec12 = document.getElementById("change12");
var sec13 = document.getElementById("change13");
var sec14 = document.getElementById("change14");
